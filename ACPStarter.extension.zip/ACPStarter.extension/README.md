# SEEN Tools pyRevit Extension

The Revit ribbon is arranged in this order:

1. **Updates** — Check for Updates.
2. **Panels** — Manage Panels, a **Panel Parameters** drop-down, and a **Panel Reports** drop-down.
3. **Families** — Convert In-Place to Family and Change Family Category.
4. **Walls** — Wall Materials Inventory.

The parameter and report tools use pyRevit `.pulldown` bundles, which show an arrow and list their child tools when opened.

## Install

Copy `ACPStarter.extension` into the pyRevit extensions folder you already use, replacing the older `ACPStarter.extension`, then reload pyRevit in Revit.

## Update button

The Check for Updates button is first in the tab and is configured for `samerrarch-ops/SEEN`. The repository still needs an uploaded extension package and a published Release before the button can find an update.

## Notes

- Wall Materials Inventory reads Basic Wall type layers and is read-only.
- The family category tool changes the selected loadable family's category after confirmation.
- In-Place conversion creates a static geometry copy, saves a new `.rfa`, places it in the same transform, and leaves the original for review. Parameters, constraints, and material assignments may not transfer.
- Revit may reject a target category or placement type as incompatible.
