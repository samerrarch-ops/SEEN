# -*- coding: utf-8 -*-
import os
import sys

extension_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.append(os.path.join(extension_root, "lib"))

import acp_core

uidoc = __revit__.ActiveUIDocument
acp_core.safe_run(acp_core.open_panel_manager, uidoc.Document, uidoc)
