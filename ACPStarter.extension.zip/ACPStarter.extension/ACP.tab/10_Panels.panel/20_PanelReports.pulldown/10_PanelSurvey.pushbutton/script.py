# -*- coding: utf-8 -*-
"""Read-only ACP curtain panel survey for Revit 2022-2027.
Exports one row per outer-face edge to an Excel-readable CSV.
No Revit parameters or model geometry are modified.
"""

import math

from Autodesk.Revit.DB import (
    BuiltInCategory,
    BuiltInParameter,
    Element,
    FilteredElementCollector,
    GeometryInstance,
    Options,
    PlanarFace,
    Solid,
    UnitTypeId,
    UnitUtils,
    ViewDetailLevel,
)
from Autodesk.Revit.UI import TaskDialog
from System.IO import StreamWriter
from System.Text import UTF8Encoding
from pyrevit import forms


doc = __revit__.ActiveUIDocument.Document
MM = UnitTypeId.Millimeters
SQM = UnitTypeId.SquareMeters
CONNECT_TOLERANCE_FT = 0.0001


def element_id_number(element_id):
    if element_id is None:
        return 0
    try:
        return int(element_id.Value)
    except Exception:
        try:
            return int(element_id.IntegerValue)
        except Exception:
            return 0


def parameter_double_mm(element, built_in_parameter):
    if element is None:
        return None
    try:
        parameter = element.get_Parameter(built_in_parameter)
        if parameter is None:
            return None
        return UnitUtils.ConvertFromInternalUnits(parameter.AsDouble(), MM)
    except Exception:
        return None


def parameter_string(element, built_in_parameter):
    if element is None:
        return u""
    try:
        parameter = element.get_Parameter(built_in_parameter)
        if parameter is None:
            return u""
        value = parameter.AsString()
        return value or u""
    except Exception:
        return u""


def element_name(element):
    if element is None:
        return u""
    try:
        return Element.Name.__get__(element) or u""
    except Exception:
        return u""


def collect_solids(geometry_element):
    found = []
    if geometry_element is None:
        return found

    for geometry_object in geometry_element:
        if isinstance(geometry_object, Solid):
            if geometry_object.Faces.Size > 0 and geometry_object.Edges.Size > 0:
                found.append(geometry_object)
        elif isinstance(geometry_object, GeometryInstance):
            try:
                nested_geometry = geometry_object.GetInstanceGeometry()
                found.extend(collect_solids(nested_geometry))
            except Exception:
                pass

    return found


def unit_vector(vector):
    if vector is None or vector.GetLength() == 0:
        raise Exception("A zero-length edge tangent was found.")
    return vector.Normalize()


def order_curves(curves):
    """Connect edge curves into one closed loop using their endpoints."""
    if not curves:
        raise Exception("The face boundary has no edges.")

    remaining = list(curves)
    ordered = [remaining.pop(0)]

    while remaining:
        current_end = ordered[-1].GetEndPoint(1)
        best_index = -1
        best_reverse = False
        best_distance = None

        for index, curve in enumerate(remaining):
            start_distance = current_end.DistanceTo(curve.GetEndPoint(0))
            end_distance = current_end.DistanceTo(curve.GetEndPoint(1))

            if best_distance is None or start_distance < best_distance:
                best_index = index
                best_reverse = False
                best_distance = start_distance

            if end_distance < best_distance:
                best_index = index
                best_reverse = True
                best_distance = end_distance

        if best_distance is None or best_distance > CONNECT_TOLERANCE_FT:
            raise Exception("The face boundary edges could not be joined.")

        next_curve = remaining.pop(best_index)
        if best_reverse:
            next_curve = next_curve.CreateReversed()
        ordered.append(next_curve)

    if ordered[-1].GetEndPoint(1).DistanceTo(ordered[0].GetEndPoint(0)) > CONNECT_TOLERANCE_FT:
        raise Exception("The face boundary loop is open.")

    return ordered


def loop_sample_points(curves):
    points = []
    for curve in curves:
        curve_points = list(curve.Tessellate())
        if len(curve_points) >= 2:
            points.extend(curve_points[:-1])
    return points


def signed_projected_area(curves, face_normal):
    points = loop_sample_points(curves)
    if len(points) < 3:
        return 0.0

    origin = points[0]
    total = 0.0
    for index in range(len(points)):
        point_a = points[index].Subtract(origin)
        point_b = points[(index + 1) % len(points)].Subtract(origin)
        total += face_normal.DotProduct(point_a.CrossProduct(point_b))

    return total * 0.5


def face_boundary_loops(face):
    face_normal = unit_vector(face.FaceNormal)
    loops = []

    for edge_array in face.EdgeLoops:
        curves = []
        for edge in edge_array:
            curves.append(edge.AsCurveFollowingFace(face))
        ordered = order_curves(curves)
        area = signed_projected_area(ordered, face_normal)
        loops.append((ordered, area))

    if not loops:
        raise Exception("No closed boundary loop was found on the face.")

    outer_curves, outer_area = max(loops, key=lambda item: abs(item[1]))

    # Normalize the outer loop so its direction follows the face normal.
    if outer_area < 0:
        outer_curves = [curve.CreateReversed() for curve in reversed(outer_curves)]

    return outer_curves, face_normal


def largest_planar_face(panel):
    options = Options()
    options.DetailLevel = ViewDetailLevel.Fine
    options.IncludeNonVisibleObjects = False

    geometry = panel.get_Geometry(options)
    solids = collect_solids(geometry)

    candidates = []
    for solid in solids:
        for face in solid.Faces:
            if isinstance(face, PlanarFace) and face.Area > 0:
                candidates.append(face)

    if not candidates:
        return None

    return max(candidates, key=lambda face: face.Area)


def corner_angle_at_curve_end(curves, index, face_normal):
    current_curve = curves[index]
    next_curve = curves[(index + 1) % len(curves)]

    incoming = unit_vector(current_curve.ComputeDerivatives(1.0, True).BasisX)
    outgoing = unit_vector(next_curve.ComputeDerivatives(0.0, True).BasisX)

    signed_turn = math.atan2(
        face_normal.DotProduct(incoming.CrossProduct(outgoing)),
        incoming.DotProduct(outgoing),
    )
    interior_angle = math.pi - signed_turn

    while interior_angle < 0:
        interior_angle += 2.0 * math.pi
    while interior_angle >= 2.0 * math.pi:
        interior_angle -= 2.0 * math.pi

    return math.degrees(interior_angle)


def bounding_box_center(element):
    try:
        box = element.get_BoundingBox(None)
        if box is None:
            return None
        return (
            (box.Min.X + box.Max.X) * 0.5,
            (box.Min.Y + box.Max.Y) * 0.5,
            (box.Min.Z + box.Max.Z) * 0.5,
        )
    except Exception:
        return None


def host_details(panel):
    try:
        parameter = panel.get_Parameter(BuiltInParameter.CURTAIN_WALL_PANEL_HOST_ID)
        if parameter is None:
            return 0, u""
        host_id = parameter.AsElementId()
        host = doc.GetElement(host_id)
        if host is None:
            return element_id_number(host_id), u""
        host_type = doc.GetElement(host.GetTypeId())
        host_type_name = element_name(host_type)
        return element_id_number(host_id), host_type_name
    except Exception:
        return 0, u""


def inspect_panel(panel):
    panel_type = doc.GetElement(panel.GetTypeId())
    panel_id = element_id_number(panel.Id)
    center = bounding_box_center(panel)
    host_id, host_type_name = host_details(panel)

    result = {
        "element_id": panel_id,
        "unique_id": panel.UniqueId,
        "mark": parameter_string(panel, BuiltInParameter.ALL_MODEL_MARK),
        "panel_type": element_name(panel_type),
        "host_id": host_id,
        "host_type": host_type_name,
        "width_mm": parameter_double_mm(panel, BuiltInParameter.CURTAIN_WALL_PANELS_WIDTH),
        "height_mm": parameter_double_mm(panel, BuiltInParameter.CURTAIN_WALL_PANELS_HEIGHT),
        "thickness_mm": parameter_double_mm(panel_type, BuiltInParameter.CURTAIN_WALL_SYSPANEL_THICKNESS),
        "offset_mm": parameter_double_mm(panel_type, BuiltInParameter.CURTAIN_WALL_SYSPANEL_OFFSET),
        "center": center,
        "face_area_sqm": None,
        "normal": None,
        "curves": [],
        "angles": [],
        "status": u"OK",
    }

    try:
        face = largest_planar_face(panel)
        if face is None:
            result["status"] = u"NO_PLANAR_FACE"
            return result

        curves, face_normal = face_boundary_loops(face)
        result["face_area_sqm"] = UnitUtils.ConvertFromInternalUnits(face.Area, SQM)
        result["normal"] = (face_normal.X, face_normal.Y, face_normal.Z)
        result["curves"] = curves
        result["angles"] = [
            corner_angle_at_curve_end(curves, index, face_normal)
            for index in range(len(curves))
        ]
    except Exception as error:
        result["status"] = u"GEOMETRY_REVIEW: {0}".format(error)

    return result


def format_number(value, decimals=2):
    if value is None:
        return u""
    return u"%.*f" % (decimals, float(value))


def csv_cell(value):
    if value is None:
        text = u""
    else:
        try:
            text = unicode(value)
        except Exception:
            text = str(value)

    text = text.replace(u"\r", u" ").replace(u"\n", u" ")
    if u"," in text or u'"' in text:
        text = u'"' + text.replace(u'"', u'""') + u'"'
    return text


def write_csv_row(writer, values):
    writer.WriteLine(u",".join([csv_cell(value) for value in values]))


def mm_xyz(point):
    if point is None:
        return u"", u"", u""
    return (
        format_number(UnitUtils.ConvertFromInternalUnits(point.X, MM)),
        format_number(UnitUtils.ConvertFromInternalUnits(point.Y, MM)),
        format_number(UnitUtils.ConvertFromInternalUnits(point.Z, MM)),
    )


panels = list(
    FilteredElementCollector(doc)
    .OfCategory(BuiltInCategory.OST_CurtainWallPanels)
    .WhereElementIsNotElementType()
)

if not panels:
    TaskDialog.Show("ACP Panel Survey", "No Curtain Wall Panels were found in this project.")
else:
    records = [inspect_panel(panel) for panel in panels]

    def panel_sort_key(record):
        center = record["center"] or (0.0, 0.0, 0.0)
        return (
            record["host_id"],
            round(center[2], 6),
            round(center[1], 6),
            round(center[0], 6),
            record["element_id"],
        )

    records.sort(key=panel_sort_key)

    output_path = forms.save_file(
        file_ext="csv",
        files_filter="Excel-readable CSV (*.csv)|*.csv",
        default_name="ACP_Panel_Survey.csv",
        title="Save ACP Panel Survey",
    )

    if output_path:
        headers = [
            "Sequence",
            "ElementId",
            "UniqueId",
            "Mark",
            "PanelType",
            "HostElementId",
            "HostWallType",
            "ModelWidth_mm",
            "ModelHeight_mm",
            "SystemPanelThickness_mm",
            "SystemPanelOffset_mm",
            "MainFaceArea_m2",
            "BBoxCenterX_mm",
            "BBoxCenterY_mm",
            "BBoxCenterZ_mm",
            "FaceNormalX",
            "FaceNormalY",
            "FaceNormalZ",
            "EdgeCount",
            "EdgeNumber",
            "EdgeCurveType",
            "EdgeLength_mm",
            "EdgeStartX_mm",
            "EdgeStartY_mm",
            "EdgeStartZ_mm",
            "EdgeEndX_mm",
            "EdgeEndY_mm",
            "EdgeEndZ_mm",
            "InteriorAngleAtEdgeEnd_deg",
            "Status",
        ]

        writer = None
        save_error = None
        try:
            writer = StreamWriter(output_path, False, UTF8Encoding(True))
            write_csv_row(writer, headers)

            for index, record in enumerate(records):
                sequence = u"ACP-{0:04d}".format(index + 1)
                center = record["center"]
                if center is None:
                    center_mm = (u"", u"", u"")
                else:
                    center_mm = tuple(
                        format_number(UnitUtils.ConvertFromInternalUnits(value, MM))
                        for value in center
                    )

                normal = record["normal"] or (None, None, None)
                edge_count = len(record["curves"])
                common = [
                    sequence,
                    record["element_id"],
                    record["unique_id"],
                    record["mark"],
                    record["panel_type"],
                    record["host_id"],
                    record["host_type"],
                    format_number(record["width_mm"]),
                    format_number(record["height_mm"]),
                    format_number(record["thickness_mm"]),
                    format_number(record["offset_mm"]),
                    format_number(record["face_area_sqm"], 4),
                    center_mm[0],
                    center_mm[1],
                    center_mm[2],
                    format_number(normal[0], 6),
                    format_number(normal[1], 6),
                    format_number(normal[2], 6),
                    edge_count,
                ]

                if edge_count == 0:
                    write_csv_row(writer, common + [u""] * 10 + [record["status"]])
                    continue

                for edge_index, curve in enumerate(record["curves"]):
                    start = curve.GetEndPoint(0)
                    end = curve.GetEndPoint(1)
                    start_mm = mm_xyz(start)
                    end_mm = mm_xyz(end)
                    edge_length = UnitUtils.ConvertFromInternalUnits(curve.Length, MM)

                    write_csv_row(
                        writer,
                        common
                        + [
                            edge_index + 1,
                            curve.GetType().Name,
                            format_number(edge_length),
                            start_mm[0],
                            start_mm[1],
                            start_mm[2],
                            end_mm[0],
                            end_mm[1],
                            end_mm[2],
                            format_number(record["angles"][edge_index]),
                            record["status"],
                        ],
                    )
        except Exception as error:
            save_error = error
        finally:
            if writer is not None:
                writer.Close()

        if save_error is not None:
            TaskDialog.Show("ACP Panel Survey", "Could not save the report:\n{0}".format(save_error))
        else:
            TaskDialog.Show(
                "ACP Panel Survey",
                "Report saved for {0} panels.\n\n"
                "Sequence numbers are in the report only. "
                "No Revit model parameters were changed.\n"
                "Panels are ordered by host, then Z, Y, X, and ElementId.".format(len(records)),
            )
