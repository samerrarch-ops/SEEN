# -*- coding: utf-8 -*-
"""Create a loadable family from the solid geometry of one in-place instance."""

import os
import re

from pyrevit import DB, forms, revit


MIN_SOLID_VOLUME = 1e-9


def element_name(element):
    if element is None:
        return "(no name)"
    try:
        return element.Name
    except Exception:
        try:
            return DB.Element.Name.__get__(element)
        except Exception:
            return "(unnamed)"


class FamilyLoadOptions(DB.IFamilyLoadOptions):
    def OnFamilyFound(self, familyInUse, overwriteParameterValues):
        overwriteParameterValues.Value = False
        return True

    def OnSharedFamilyFound(
        self, sharedFamily, familyInUse, source, overwriteParameterValues
    ):
        source.Value = DB.FamilySource.Family
        overwriteParameterValues.Value = False
        return True


def choose_one(items, title, button_name):
    result = forms.SelectFromList.show(
        items,
        title=title,
        button_name=button_name,
        multiselect=False,
    )
    if isinstance(result, list):
        return result[0] if result else None
    return result


def find_generic_model_template(application):
    """Find an installed Generic Model family template."""
    template_root = application.FamilyTemplatePath
    preferred_names = (
        "metric generic model.rft",
        "generic model.rft",
    )

    if template_root and os.path.isdir(template_root):
        for root, folders, files in os.walk(template_root):
            for file_name in files:
                if file_name.lower() in preferred_names:
                    return os.path.join(root, file_name)

    # If the configured language uses another template name, let the user browse.
    return forms.pick_file(
        file_ext="rft",
        files_filter="Revit Family Template (*.rft)|*.rft",
        init_dir=template_root,
        title="Choose a Generic Model family template",
    )


def collect_world_solids(geometry_element, current_transform):
    """Walk nested geometry and return solids transformed to project coordinates."""
    solids = []
    if geometry_element is None:
        return solids

    for geometry_object in geometry_element:
        if isinstance(geometry_object, DB.Solid):
            if geometry_object.Volume > MIN_SOLID_VOLUME:
                if current_transform.IsIdentity:
                    solids.append(geometry_object)
                else:
                    try:
                        solids.append(
                            DB.SolidUtils.CreateTransformed(
                                geometry_object, current_transform
                            )
                        )
                    except Exception:
                        pass

        elif isinstance(geometry_object, DB.GeometryInstance):
            nested_transform = current_transform.Multiply(geometry_object.Transform)
            nested_solids = collect_world_solids(
                geometry_object.GetSymbolGeometry(), nested_transform
            )
            solids.extend(nested_solids)

    return solids


def clean_file_name(name):
    cleaned = re.sub(r'[<>:"/\\|?*]', "_", name).strip()
    if not cleaned:
        cleaned = "Converted_InPlace"
    return cleaned


def main():
    document = revit.doc
    if document is None:
        forms.alert("Open a Revit project first.", title="Convert In-Place")
        return

    selected_ids = list(revit.uidoc.Selection.GetElementIds())
    if len(selected_ids) != 1:
        forms.alert(
            "Select exactly one in-place model in Revit, then run this button.",
            title="Convert In-Place",
        )
        return

    source_element = document.GetElement(selected_ids[0])
    if not isinstance(source_element, DB.FamilyInstance):
        forms.alert(
            "The selected element is not a family instance.",
            title="Convert In-Place",
        )
        return

    if source_element.Symbol is None or not source_element.Symbol.Family.IsInPlace:
        forms.alert(
            "The selected family is not an in-place family.",
            title="Convert In-Place",
        )
        return

    source_family_name = element_name(source_element.Symbol.Family)
    confirmed = forms.alert(
        "Create a new loadable family from the solid shape of '{}'?\n\n"
        "The new family will be placed at the same position. The original stays in the project.\n"
        "The copy is static geometry; original parameters, constraints, and material assignments may not transfer.".format(
            source_family_name
        ),
        title="Confirm Geometry Copy",
        ok=False,
        yes=True,
        no=True,
        icon="warning",
    )
    if not confirmed:
        return

    geometry_options = DB.Options()
    geometry_options.IncludeNonVisibleObjects = False
    geometry_options.ComputeReferences = False

    try:
        source_transform = source_element.GetTransform()
        inverse_transform = source_transform.Inverse
        geometry = source_element.get_Geometry(geometry_options)
        world_solids = collect_world_solids(geometry, DB.Transform.Identity)
        local_solids = [
            DB.SolidUtils.CreateTransformed(solid, inverse_transform)
            for solid in world_solids
        ]
    except Exception as error:
        forms.alert(
            "Revit could not read the selected model's solid geometry.\n\n{}".format(
                error
            ),
            title="Convert In-Place",
            icon="error",
        )
        return

    if not local_solids:
        forms.alert(
            "No solid geometry was found. This first version needs solid forms; open surfaces are not converted.",
            title="Convert In-Place",
            icon="error",
        )
        return

    template_path = find_generic_model_template(document.Application)
    if not template_path:
        forms.alert(
            "No family template was selected. The project was not changed.",
            title="Convert In-Place",
        )
        return

    family_document = None
    family_loaded = False
    try:
        family_document = document.Application.NewFamilyDocument(template_path)
        if family_document is None:
            raise Exception("Revit could not create a family document from that template.")

        categories = [
            category
            for category in family_document.Settings.Categories
            if category.CategoryType == DB.CategoryType.Model
        ]
        category_by_choice = {}
        category_choices = []
        for category in categories:
            choice = "{} | ID {}".format(
                element_name(category), category.Id.ToString()
            )
            category_choices.append(choice)
            category_by_choice[choice] = category

        category_choice = choose_one(
            sorted(category_choices),
            "Choose the new family category",
            "Create Family",
        )
        if category_choice is None:
            return
        target_category = category_by_choice[category_choice]

        safe_name = clean_file_name(source_family_name)
        output_path = forms.save_file(
            file_ext="rfa",
            files_filter="Revit Family (*.rfa)|*.rfa",
            default_name="{}_Converted.rfa".format(safe_name),
            title="Save the new loadable family",
        )
        if not output_path:
            return

        family_transaction = DB.Transaction(
            family_document, "Create Static Family Geometry"
        )
        family_transaction.Start()
        try:
            family_document.OwnerFamily.FamilyCategory = target_category
            for solid in local_solids:
                DB.FreeFormElement.Create(family_document, solid)
            family_transaction.Commit()
        except Exception:
            if family_transaction.HasStarted():
                family_transaction.RollBack()
            raise

        family_document.SaveAs(output_path)
        loaded_family = family_document.LoadFamily(
            document, FamilyLoadOptions()
        )
        if loaded_family is None:
            raise Exception(
                "Revit did not load the new family. The original in-place model is unchanged."
            )
        family_loaded = True

        symbol_ids = list(loaded_family.GetFamilySymbolIds())
        if not symbol_ids:
            raise Exception(
                "The new family loaded, but it has no available type to place."
            )
        family_symbol = document.GetElement(symbol_ids[0])

        project_transaction = DB.Transaction(
            document, "Place Converted Family Copy"
        )
        project_transaction.Start()
        try:
            if not family_symbol.IsActive:
                family_symbol.Activate()
            new_instance = document.Create.NewFamilyInstance(
                DB.XYZ.Zero,
                family_symbol,
                DB.Structure.StructuralType.NonStructural,
            )
            DB.ElementTransformUtils.TransformElement(
                document, new_instance.Id, source_transform
            )
            project_transaction.Commit()
        except Exception:
            if project_transaction.HasStarted():
                project_transaction.RollBack()
            raise

        forms.alert(
            "Created and placed the new family.\n\n"
            "Category: {}\nFamily file: {}\n\n"
            "The original in-place model remains in the project for review.".format(
                element_name(target_category), output_path
            ),
            title="Convert In-Place",
            icon="information",
        )

    except Exception as error:
        extra = ""
        if family_loaded:
            extra = "\nThe new family was loaded into the project, but placement did not finish."
        forms.alert(
            "Could not complete the geometry copy.\n\n{}{}".format(error, extra),
            title="Convert In-Place",
            icon="error",
        )
    finally:
        if family_document is not None:
            try:
                family_document.Close(False)
            except Exception:
                pass


main()
