# -*- coding: utf-8 -*-
"""Change the category of one editable, loaded family."""

from pyrevit import DB, forms, revit


def element_name(element):
    if element is None:
        return "(no name)"
    try:
        return element.Name
    except Exception:
        try:
            return DB.Element.Name.__get__(element)
        except Exception:
            return "(unnamed)"


class FamilyLoadOptions(DB.IFamilyLoadOptions):
    """Allow the edited family to be loaded back into the open project."""

    def OnFamilyFound(self, familyInUse, overwriteParameterValues):
        # Preserve parameter values already stored in the project.
        overwriteParameterValues.Value = False
        return True

    def OnSharedFamilyFound(
        self, sharedFamily, familyInUse, source, overwriteParameterValues
    ):
        source.Value = DB.FamilySource.Family
        overwriteParameterValues.Value = False
        return True


def selected_item(items, title, button_name):
    """Show a one-choice list and normalize pyRevit's return value."""
    result = forms.SelectFromList.show(
        items,
        title=title,
        button_name=button_name,
        multiselect=False,
    )
    if isinstance(result, list):
        return result[0] if result else None
    return result


def main():
    document = revit.doc
    if document is None:
        forms.alert("Open a Revit project first.", title="Change Family Category")
        return

    # In-place families cannot be opened with Document.EditFamily.
    families = DB.FilteredElementCollector(document).OfClass(DB.Family).ToElements()
    editable_families = [
        family
        for family in families
        if not family.IsInPlace and family.IsEditable
    ]

    if not editable_families:
        forms.alert(
            "No editable, loaded families were found in this project.",
            title="Change Family Category",
        )
        return

    family_by_choice = {}
    family_choices = []
    for family in editable_families:
        family_name = element_name(family)
        category_name = element_name(family.FamilyCategory)
        choice = "{} | {} | ID {}".format(
            family_name, category_name, family.Id.ToString()
        )
        family_choices.append(choice)
        family_by_choice[choice] = family

    family_choice = selected_item(
        sorted(family_choices),
        "Choose a family",
        "Next",
    )
    if family_choice is None:
        return

    selected_family = family_by_choice[family_choice]
    family_document = None

    try:
        # Edit a temporary family document; the project changes only after reload.
        family_document = document.EditFamily(selected_family)
        categories = [
            category
            for category in family_document.Settings.Categories
            if category.CategoryType == DB.CategoryType.Model
        ]
        category_by_name = dict(
            (element_name(category), category) for category in categories
        )
        category_names = sorted(category_by_name.keys())

        new_category_name = selected_item(
            category_names,
            "Choose a new model category",
            "Change Category",
        )
        if new_category_name is None:
            return

        new_category = category_by_name[new_category_name]
        old_category_name = element_name(family_document.OwnerFamily.FamilyCategory)
        if new_category_name == old_category_name:
            forms.alert(
                "This family already uses the selected category.",
                title="Change Family Category",
            )
            return

        confirmed = forms.alert(
            "Change family '{}' from '{}' to '{}'?\n\n"
            "This changes the family definition and affects its instances in this project.".format(
                element_name(family_document.OwnerFamily),
                old_category_name,
                new_category_name,
            ),
            title="Confirm Category Change",
            ok=False,
            yes=True,
            no=True,
            icon="warning",
        )
        if not confirmed:
            return

        transaction = DB.Transaction(family_document, "Change Family Category")
        transaction.Start()
        try:
            family_document.OwnerFamily.FamilyCategory = new_category
            transaction.Commit()
        except Exception:
            if transaction.HasStarted():
                transaction.RollBack()
            raise

        loaded_family = family_document.LoadFamily(
            document, FamilyLoadOptions()
        )
        if loaded_family is None:
            forms.alert(
                "Revit did not reload the changed family. The project was not updated.",
                title="Change Family Category",
                icon="error",
            )
            return

        forms.alert(
            "Changed '{}' to category '{}'.".format(
                element_name(loaded_family), new_category_name
            ),
            title="Change Family Category",
            icon="information",
        )

    except Exception as error:
        forms.alert(
            "Revit could not change this family's category.\n\n{}".format(error),
            title="Change Family Category",
            icon="error",
        )
    finally:
        if family_document is not None:
            try:
                family_document.Close(False)
            except Exception:
                pass


main()
