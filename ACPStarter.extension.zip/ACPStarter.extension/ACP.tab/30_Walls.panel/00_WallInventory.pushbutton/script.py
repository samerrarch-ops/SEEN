# -*- coding: utf-8 -*-
"""Beginner-friendly, read-only wall type and material inventory."""

from pyrevit import DB, forms, revit


# Revit stores length in feet and area in square feet internally.
SQFT_TO_SQM = 0.09290304
FEET_TO_MM = 304.8


def element_name(element):
    """Read an element name, including Revit versions with IronPython quirks."""
    if element is None:
        return "(no material assigned)"

    try:
        return element.Name
    except Exception:
        try:
            return DB.Element.Name.__get__(element)
        except Exception:
            return "(unnamed)"


def wall_area_sqm(wall):
    """Return a wall's computed area in square meters, or zero if unavailable."""
    try:
        area_parameter = wall.get_Parameter(DB.BuiltInParameter.HOST_AREA_COMPUTED)
        if area_parameter and area_parameter.HasValue:
            return area_parameter.AsDouble() * SQFT_TO_SQM
    except Exception:
        pass
    return 0.0


def get_layer_summary(document, wall_type):
    """Describe the material layers defined by a wall type."""
    if wall_type.Kind != DB.WallKind.Basic:
        return "Layer materials: type is not a Basic Wall; inspect its components separately."

    try:
        compound_structure = wall_type.GetCompoundStructure()
    except Exception:
        compound_structure = None

    if compound_structure is None:
        return "Layer materials: no compound structure is available."

    layer_descriptions = []
    for index, layer in enumerate(compound_structure.GetLayers()):
        material = document.GetElement(layer.MaterialId)
        material_name = element_name(material)
        thickness_mm = layer.Width * FEET_TO_MM
        function_name = str(layer.Function)
        layer_descriptions.append(
            "{}. {} | {} | {:.1f} mm".format(
                index + 1, function_name, material_name, thickness_mm
            )
        )

    if not layer_descriptions:
        return "Layer materials: this type has no layers."

    return "Layers (outside to inside):\n  " + "\n  ".join(layer_descriptions)


def main():
    document = revit.doc
    if document is None:
        forms.alert("Open a Revit project, then run this button again.", title="Wall Inventory")
        return

    # Collect placed wall instances, not the wall type definitions.
    walls = (
        DB.FilteredElementCollector(document)
        .OfClass(DB.Wall)
        .WhereElementIsNotElementType()
        .ToElements()
    )

    if not walls:
        forms.alert("No wall instances were found in this project.", title="Wall Inventory")
        return

    # Group the placed walls by type so each type appears once in the report.
    grouped_walls = {}
    for wall in walls:
        type_id = wall.GetTypeId()
        key = type_id.ToString()
        if key not in grouped_walls:
            wall_type = document.GetElement(type_id)
            grouped_walls[key] = {
                "type": wall_type,
                "count": 0,
                "area_sqm": 0.0,
            }

        grouped_walls[key]["count"] += 1
        grouped_walls[key]["area_sqm"] += wall_area_sqm(wall)

    report_lines = [
        "Wall instances found: {}".format(len(walls)),
        "Unique wall types used: {}".format(len(grouped_walls)),
        "",
    ]

    # Keep the first lesson's preview readable if a model has many types.
    displayed_groups = list(grouped_walls.values())[:20]
    for group in displayed_groups:
        wall_type = group["type"]
        report_lines.append("TYPE: {}".format(element_name(wall_type)))
        report_lines.append("Instances: {}".format(group["count"]))
        report_lines.append("Total wall area: {:.2f} m2".format(group["area_sqm"]))
        report_lines.append(get_layer_summary(document, wall_type))
        report_lines.append("")

    if len(grouped_walls) > len(displayed_groups):
        report_lines.append(
            "Preview shows 20 types. {} more types were found.".format(
                len(grouped_walls) - len(displayed_groups)
            )
        )

    forms.alert("\n".join(report_lines), title="Wall Materials Inventory")


main()
