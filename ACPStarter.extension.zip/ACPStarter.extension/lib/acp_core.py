# -*- coding: utf-8 -*-
"""Shared pyRevit helpers for ACP curtain-wall panel tools.

Compatible with IronPython 2.7 and Revit 2022+. Length and angle shared
parameters store plain numeric millimetres/degrees so schedules and exports
are unambiguous across project unit settings.
"""

import math
import json
import os
import re
import uuid
import zipfile
from collections import defaultdict

import Autodesk.Revit.DB as DB
from System import Guid
from System.IO import Directory, File, Path
from System.Text import UTF8Encoding
from pyrevit import forms


EXTENSION_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
PARAMETER_FILE = os.path.join(EXTENSION_ROOT, "ACP_SharedParameters.txt")
PARAMETER_GROUP = "ACP Panel Data"
CONNECT_TOLERANCE_FT = 0.0001


def _unit_id(new_name, old_name):
    try:
        return getattr(DB.UnitTypeId, new_name)
    except Exception:
        return getattr(DB.DisplayUnitType, old_name)


MM = _unit_id("Millimeters", "DUT_MILLIMETERS")
SQM = _unit_id("SquareMeters", "DUT_SQUARE_METERS")
CUBIC_METERS = _unit_id("CubicMeters", "DUT_CUBIC_METERS")


def to_mm(value_ft):
    if value_ft is None:
        return None
    return DB.UnitUtils.ConvertFromInternalUnits(value_ft, MM)


def from_mm(value_mm):
    return DB.UnitUtils.ConvertToInternalUnits(float(value_mm), MM)


def to_sqm(value_sqft):
    if value_sqft is None:
        return None
    return DB.UnitUtils.ConvertFromInternalUnits(value_sqft, SQM)


def to_cubic_m(value_cuft):
    if value_cuft is None:
        return None
    return DB.UnitUtils.ConvertFromInternalUnits(value_cuft, CUBIC_METERS)


def element_id_number(element_id):
    if element_id is None:
        return 0
    try:
        return int(element_id.Value)
    except Exception:
        try:
            return int(element_id.IntegerValue)
        except Exception:
            return 0


def element_name(element):
    if element is None:
        return u""
    try:
        return DB.Element.Name.__get__(element) or u""
    except Exception:
        try:
            return unicode(element.Name)
        except Exception:
            return u""


def _param_double(element, built_in_parameter):
    if element is None:
        return None
    try:
        parameter = element.get_Parameter(built_in_parameter)
        if parameter is not None and parameter.StorageType == DB.StorageType.Double:
            return parameter.AsDouble()
    except Exception:
        pass
    return None


def _parameter_text(element, name):
    try:
        parameter = element.LookupParameter(name)
        if parameter is not None and parameter.StorageType == DB.StorageType.String:
            return parameter.AsString() or u""
    except Exception:
        pass
    return u""


def parameter_double_mm(element, built_in_parameter):
    return to_mm(_param_double(element, built_in_parameter))


def _unit_vector(vector):
    if vector is None or vector.GetLength() == 0:
        raise Exception("A zero-length edge tangent was found.")
    return vector.Normalize()


def _order_curves(curves):
    if not curves:
        raise Exception("The face boundary has no edges.")
    remaining = list(curves)
    ordered = [remaining.pop(0)]
    while remaining:
        current_end = ordered[-1].GetEndPoint(1)
        best_index = -1
        best_reverse = False
        best_distance = None
        for index, curve in enumerate(remaining):
            start_distance = current_end.DistanceTo(curve.GetEndPoint(0))
            end_distance = current_end.DistanceTo(curve.GetEndPoint(1))
            if best_distance is None or start_distance < best_distance:
                best_index = index
                best_reverse = False
                best_distance = start_distance
            if end_distance < best_distance:
                best_index = index
                best_reverse = True
                best_distance = end_distance
        if best_distance is None or best_distance > CONNECT_TOLERANCE_FT:
            raise Exception("The face boundary edges could not be joined.")
        next_curve = remaining.pop(best_index)
        if best_reverse:
            next_curve = next_curve.CreateReversed()
        ordered.append(next_curve)
    if ordered[-1].GetEndPoint(1).DistanceTo(ordered[0].GetEndPoint(0)) > CONNECT_TOLERANCE_FT:
        raise Exception("The face boundary loop is open.")
    return ordered


def _loop_sample_points(curves):
    points = []
    for curve in curves:
        curve_points = list(curve.Tessellate())
        if len(curve_points) >= 2:
            points.extend(curve_points[:-1])
    return points


def _signed_projected_area(curves, face_normal):
    points = _loop_sample_points(curves)
    if len(points) < 3:
        return 0.0
    origin = points[0]
    total = 0.0
    for index in range(len(points)):
        point_a = points[index].Subtract(origin)
        point_b = points[(index + 1) % len(points)].Subtract(origin)
        total += face_normal.DotProduct(point_a.CrossProduct(point_b))
    return total * 0.5


def _face_boundary_loops(face):
    face_normal = _unit_vector(face.FaceNormal)
    loops = []
    for edge_array in face.EdgeLoops:
        curves = [edge.AsCurveFollowingFace(face) for edge in edge_array]
        ordered = _order_curves(curves)
        loops.append((ordered, _signed_projected_area(ordered, face_normal)))
    if not loops:
        raise Exception("No closed boundary loop was found on the face.")
    outer_curves, outer_area = max(loops, key=lambda item: abs(item[1]))
    if outer_area < 0:
        outer_curves = [curve.CreateReversed() for curve in reversed(outer_curves)]
    return outer_curves, face_normal


def _collect_solids(geometry_element):
    found = []
    if geometry_element is None:
        return found
    for geometry_object in geometry_element:
        if isinstance(geometry_object, DB.Solid):
            if geometry_object.Faces.Size > 0 and geometry_object.Edges.Size > 0:
                found.append(geometry_object)
        elif isinstance(geometry_object, DB.GeometryInstance):
            try:
                found.extend(_collect_solids(geometry_object.GetInstanceGeometry()))
            except Exception:
                pass
    return found


def _largest_planar_face(panel):
    options = DB.Options()
    options.DetailLevel = DB.ViewDetailLevel.Fine
    options.IncludeNonVisibleObjects = False
    solids = _collect_solids(panel.get_Geometry(options))
    candidates = []
    for solid in solids:
        for face in solid.Faces:
            if isinstance(face, DB.PlanarFace) and face.Area > 0:
                candidates.append(face)
    if not candidates:
        return None
    return max(candidates, key=lambda face: face.Area)


def _corner_angle_at_curve_end(curves, index, face_normal):
    current_curve = curves[index]
    next_curve = curves[(index + 1) % len(curves)]
    incoming = _unit_vector(current_curve.ComputeDerivatives(1.0, True).BasisX)
    outgoing = _unit_vector(next_curve.ComputeDerivatives(0.0, True).BasisX)
    signed_turn = math.atan2(
        face_normal.DotProduct(incoming.CrossProduct(outgoing)),
        incoming.DotProduct(outgoing),
    )
    interior_angle = math.pi - signed_turn
    while interior_angle < 0:
        interior_angle += 2.0 * math.pi
    while interior_angle >= 2.0 * math.pi:
        interior_angle -= 2.0 * math.pi
    return math.degrees(interior_angle)


def _bounding_box_center(element):
    try:
        box = element.get_BoundingBox(None)
        if box is None:
            return None
        return DB.XYZ(
            (box.Min.X + box.Max.X) * 0.5,
            (box.Min.Y + box.Max.Y) * 0.5,
            (box.Min.Z + box.Max.Z) * 0.5,
        )
    except Exception:
        return None


def _host_details(doc, panel):
    try:
        parameter = panel.get_Parameter(DB.BuiltInParameter.CURTAIN_WALL_PANEL_HOST_ID)
        if parameter is None:
            return 0, u""
        host_id = parameter.AsElementId()
        host = doc.GetElement(host_id)
        if host is None:
            return element_id_number(host_id), u""
        return element_id_number(host_id), element_name(doc.GetElement(host.GetTypeId()))
    except Exception:
        return 0, u""


def _material_rows(doc, panel):
    rows = []
    try:
        for paint_material in (False, True):
            for material_id in panel.GetMaterialIds(paint_material):
                material = doc.GetElement(material_id)
                area = None
                volume = None
                try:
                    area = to_sqm(panel.GetMaterialArea(material_id, paint_material))
                except Exception:
                    pass
                if not paint_material:
                    try:
                        volume = to_cubic_m(panel.GetMaterialVolume(material_id))
                    except Exception:
                        pass
                rows.append({
                    "id": element_id_number(material_id),
                    "name": element_name(material),
                    "area_sqm": area,
                    "volume_m3": volume,
                    "source": u"Paint" if paint_material else u"Element material",
                })
    except Exception:
        pass
    return rows


def inspect_panel(doc, panel):
    panel_type = doc.GetElement(panel.GetTypeId())
    center = _bounding_box_center(panel)
    host_id, host_type = _host_details(doc, panel)
    result = {
        "panel": panel,
        "panel_type_element": panel_type,
        "element_id": element_id_number(panel.Id),
        "unique_id": panel.UniqueId,
        "existing_name": _parameter_text(panel, "ACP_Panel_Name"),
        "existing_serial": _parameter_text(panel, "ACP_Serial_Number"),
        "panel_type": element_name(panel_type),
        "host_id": host_id,
        "host_type": host_type,
        "width_mm": parameter_double_mm(panel, DB.BuiltInParameter.CURTAIN_WALL_PANELS_WIDTH),
        "height_mm": parameter_double_mm(panel, DB.BuiltInParameter.CURTAIN_WALL_PANELS_HEIGHT),
        "thickness_mm": parameter_double_mm(panel_type, DB.BuiltInParameter.CURTAIN_WALL_SYSPANEL_THICKNESS),
        "offset_mm": parameter_double_mm(panel_type, DB.BuiltInParameter.CURTAIN_WALL_SYSPANEL_OFFSET),
        "center": center,
        "face_area_sqm": None,
        "normal": None,
        "curves": [],
        "angles": [],
        "materials": _material_rows(doc, panel),
        "status": u"OK",
    }
    try:
        face = _largest_planar_face(panel)
        if face is None:
            result["status"] = u"NO_PLANAR_FACE"
            return result
        curves, face_normal = _face_boundary_loops(face)
        result["face_area_sqm"] = to_sqm(face.Area)
        result["normal"] = (face_normal.X, face_normal.Y, face_normal.Z)
        result["curves"] = curves
        result["angles"] = [
            _corner_angle_at_curve_end(curves, index, face_normal)
            for index in range(len(curves))
        ]
    except Exception as error:
        result["status"] = u"GEOMETRY_REVIEW: {0}".format(error)
    return result


def collect_panel_records(doc, require_geometry=False):
    panels = list(
        DB.FilteredElementCollector(doc)
        .OfCategory(DB.BuiltInCategory.OST_CurtainWallPanels)
        .WhereElementIsNotElementType()
    )
    records = [inspect_panel(doc, panel) for panel in panels]

    def sort_key(record):
        center = record["center"]
        if center is None:
            center = DB.XYZ(0, 0, 0)
        return (
            record["host_id"],
            round(center.Z, 6),
            round(center.Y, 6),
            round(center.X, 6),
            record["element_id"],
        )

    records.sort(key=sort_key)
    _allocate_identifiers(records)
    return records


def _allocate_identifiers(records):
    used_names = set()
    used_serials = set()
    for record in records:
        name = (record.get("existing_name") or u"").strip()
        serial = (record.get("existing_serial") or u"").strip()
        if re.match(u"^ACP-[0-9]{4,}$", name) and name not in used_names:
            record["name"] = name
            used_names.add(name)
        else:
            record["name"] = None
        if re.match(u"^[A-Z][0-9]{4}$", serial) and serial not in used_serials:
            record["serial"] = serial
            used_serials.add(serial)
        else:
            record["serial"] = None

    name_number = 1
    serial_number = 1
    for record in records:
        if not record.get("name"):
            while True:
                candidate = u"ACP-{0:04d}".format(name_number)
                name_number += 1
                if candidate not in used_names:
                    record["name"] = candidate
                    used_names.add(candidate)
                    break
        if not record.get("serial"):
            while True:
                letter_index = (serial_number - 1) // 9999
                if letter_index >= 26:
                    raise Exception("The one-letter serial format supports up to 259,974 panels.")
                candidate = u"{0}{1:04d}".format(
                    chr(65 + letter_index), ((serial_number - 1) % 9999) + 1
                )
                serial_number += 1
                if candidate not in used_serials:
                    record["serial"] = candidate
                    used_serials.add(candidate)
                    break
        record["sequence"] = record["name"]


def _panel_specs(edge_count=0):
    specs = [
        ("ACP_Panel_Name", "text"),
        ("ACP_Serial_Number", "text"),
        ("ACP_UniqueId", "text"),
        ("ACP_HostElementId", "text"),
        ("ACP_HostType", "text"),
        ("ACP_PanelType", "text"),
        ("ACP_Material_List", "text"),
        ("ACP_Geometry_Status", "text"),
        ("ACP_Width_mm", "number"),
        ("ACP_Height_mm", "number"),
        ("ACP_Thickness_mm", "number"),
        ("ACP_Offset_mm", "number"),
        ("ACP_MainFaceArea_sqm", "number"),
        ("ACP_CenterX_mm", "number"),
        ("ACP_CenterY_mm", "number"),
        ("ACP_CenterZ_mm", "number"),
        ("ACP_FaceNormalX", "number"),
        ("ACP_FaceNormalY", "number"),
        ("ACP_FaceNormalZ", "number"),
        ("ACP_Edge_Count", "integer"),
    ]
    for index in range(1, edge_count + 1):
        specs.append(("ACP_Edge_{0:02d}_Length_mm".format(index), "number"))
        specs.append(("ACP_Corner_{0:02d}_Angle_deg".format(index), "number"))
    return specs


def _shared_parameter_guid(name):
    return Guid(str(uuid.uuid5(uuid.NAMESPACE_URL, "com.acpstarter.revit/parameters/" + name)))


def _shared_parameter_file(app):
    folder = os.path.dirname(PARAMETER_FILE)
    if not Directory.Exists(folder):
        Directory.CreateDirectory(folder)
    if not File.Exists(PARAMETER_FILE):
        seed = (
            u"# This is a Revit shared parameter file.\n"
            u"# Do not edit manually.\n"
            u"*META\tVERSION\tMINVERSION\n"
            u"META\t2\t1\n"
            u"*GROUP\tID\tNAME\n"
            u"*PARAM\tGUID\tNAME\tDATATYPE\tDATACATEGORY\tGROUP\tVISIBLE\tDESCRIPTION\tUSERMODIFIABLE\n"
        )
        File.WriteAllText(PARAMETER_FILE, seed, UTF8Encoding(False))
    original = app.SharedParametersFilename
    app.SharedParametersFilename = PARAMETER_FILE
    try:
        definition_file = app.OpenSharedParameterFile()
        if definition_file is None:
            raise Exception("Revit could not open the ACP shared parameter file.")
        group = definition_file.Groups.get_Item(PARAMETER_GROUP)
        if group is None:
            group = definition_file.Groups.Create(PARAMETER_GROUP)
        return original, definition_file, group
    except Exception:
        app.SharedParametersFilename = original
        raise


def _data_type(kind):
    if hasattr(DB, "SpecTypeId"):
        if kind == "text":
            return DB.SpecTypeId.String.Text
        if kind == "integer":
            return DB.SpecTypeId.Int.Integer
        return DB.SpecTypeId.Number
    if kind == "text":
        return DB.ParameterType.Text
    if kind == "integer":
        return DB.ParameterType.Integer
    return DB.ParameterType.Number


def _legacy_data_type(kind):
    if kind == "text":
        return DB.ParameterType.Text
    if kind == "integer":
        return DB.ParameterType.Integer
    return DB.ParameterType.Number


def _get_or_create_definitions(app, specs):
    original, definition_file, group = _shared_parameter_file(app)
    definitions = {}
    try:
        for name, kind in specs:
            definition = group.Definitions.get_Item(name)
            if definition is None:
                try:
                    options = DB.ExternalDefinitionCreationOptions(name, _data_type(kind))
                except Exception:
                    options = DB.ExternalDefinitionCreationOptions(name, _legacy_data_type(kind))
                options.GUID = _shared_parameter_guid(name)
                options.Description = u"ACP panel data maintained by the ACP Panel Tools."
                definition = group.Definitions.Create(options)
            if definition is None:
                raise Exception("Could not create shared parameter: {0}".format(name))
            try:
                if definition.GUID != _shared_parameter_guid(name):
                    raise Exception(
                        "The shared parameter file already contains a different GUID for {0}."
                        .format(name)
                    )
            except AttributeError:
                pass
            definitions[name] = definition
    finally:
        app.SharedParametersFilename = original
    return definitions


def _binding_group_id():
    try:
        return DB.GroupTypeId.IdentityData
    except Exception:
        return DB.BuiltInParameterGroup.PG_IDENTITY_DATA


def _binding_insert(binding_map, definition, binding, group_id, reinsert=False):
    method = binding_map.ReInsert if reinsert else binding_map.Insert
    try:
        return method(definition, binding, group_id)
    except Exception:
        return method(definition, binding, DB.BuiltInParameterGroup.PG_IDENTITY_DATA)


def _bind_instance_parameters(doc, definitions):
    category = DB.Category.GetCategory(doc, DB.BuiltInCategory.OST_CurtainWallPanels)
    binding_map = doc.ParameterBindings
    app = doc.Application
    for name, definition in definitions.items():
        existing_binding = None
        try:
            existing_binding = binding_map.get_Item(definition)
        except Exception:
            pass
        category_set = app.Create.NewCategorySet()
        if existing_binding is not None:
            if not isinstance(existing_binding, DB.InstanceBinding):
                raise Exception("{0} is already bound as a type parameter.".format(name))
            has_category = False
            for existing_category in existing_binding.Categories:
                category_set.Insert(existing_category)
                if element_id_number(existing_category.Id) == element_id_number(category.Id):
                    has_category = True
            if not has_category:
                category_set.Insert(category)
                binding = app.Create.NewInstanceBinding(category_set)
                if not _binding_insert(binding_map, definition, binding, _binding_group_id(), True):
                    raise Exception("Could not update category binding for {0}.".format(name))
        else:
            category_set.Insert(category)
            binding = app.Create.NewInstanceBinding(category_set)
            if not _binding_insert(binding_map, definition, binding, _binding_group_id(), False):
                raise Exception("Could not bind shared parameter {0}.".format(name))


def _set_parameter(element, name, value, kind):
    parameter = element.LookupParameter(name)
    if parameter is None:
        raise Exception("Parameter is missing on a panel: {0}".format(name))
    if parameter.IsReadOnly:
        raise Exception("Parameter is read-only: {0}".format(name))
    if value is None:
        return
    if kind == "text":
        parameter.Set(unicode(value))
    elif kind == "integer":
        parameter.Set(int(value))
    else:
        parameter.Set(float(value))


def _material_names(record):
    names = []
    for item in record["materials"]:
        if item["name"] and item["name"] not in names:
            names.append(item["name"])
    return u"; ".join(names)


def _center_mm(record):
    center = record["center"]
    if center is None:
        return (None, None, None)
    return (to_mm(center.X), to_mm(center.Y), to_mm(center.Z))


def _normal_values(record):
    return record["normal"] or (None, None, None)


def _populate_panel_parameters(doc, records, edge_count, specs):
    kinds = dict(specs)
    errors = []
    for record in records:
        panel = record["panel"]
        cx, cy, cz = _center_mm(record)
        nx, ny, nz = _normal_values(record)
        values = {
            "ACP_Panel_Name": record["name"],
            "ACP_Serial_Number": record["serial"],
            "ACP_UniqueId": record["unique_id"],
            "ACP_HostElementId": str(record["host_id"]),
            "ACP_HostType": record["host_type"],
            "ACP_PanelType": record["panel_type"],
            "ACP_Material_List": _material_names(record),
            "ACP_Geometry_Status": record["status"],
            "ACP_Width_mm": record["width_mm"],
            "ACP_Height_mm": record["height_mm"],
            "ACP_Thickness_mm": record["thickness_mm"],
            "ACP_Offset_mm": record["offset_mm"],
            "ACP_MainFaceArea_sqm": record["face_area_sqm"],
            "ACP_CenterX_mm": cx,
            "ACP_CenterY_mm": cy,
            "ACP_CenterZ_mm": cz,
            "ACP_FaceNormalX": nx,
            "ACP_FaceNormalY": ny,
            "ACP_FaceNormalZ": nz,
            "ACP_Edge_Count": len(record["curves"]),
        }
        for index in range(edge_count):
            if index < len(record["curves"]):
                values["ACP_Edge_{0:02d}_Length_mm".format(index + 1)] = to_mm(
                    record["curves"][index].Length
                )
                values["ACP_Corner_{0:02d}_Angle_deg".format(index + 1)] = record["angles"][index]
        for name, kind in specs:
            try:
                _set_parameter(panel, name, values.get(name), kind)
            except Exception as error:
                errors.append(u"{0} / {1}: {2}".format(record["sequence"], name, error))
    return errors


def _transaction(doc, title, callback):
    transaction = DB.Transaction(doc, title)
    status = transaction.Start()
    if status != DB.TransactionStatus.Started:
        raise Exception("Could not start Revit transaction: {0}".format(status))
    try:
        result = callback()
        status = transaction.Commit()
        if status != DB.TransactionStatus.Committed:
            raise Exception("Revit transaction did not commit: {0}".format(status))
        return result
    except Exception:
        try:
            if transaction.GetStatus() == DB.TransactionStatus.Started:
                transaction.RollBack()
        except Exception:
            pass
        raise


def run_assign_ids(doc):
    records = collect_panel_records(doc)
    if not records:
        forms.alert("No Curtain Wall Panels were found in this project.", title="ACP Panel Tools")
        return
    specs = [("ACP_Panel_Name", "text"), ("ACP_Serial_Number", "text")]
    definitions = _get_or_create_definitions(doc.Application, specs)

    def update():
        _bind_instance_parameters(doc, definitions)
        errors = []
        for record in records:
            for name, value in (
                ("ACP_Panel_Name", record["name"]),
                ("ACP_Serial_Number", record["serial"]),
            ):
                try:
                    _set_parameter(record["panel"], name, value, "text")
                except Exception as error:
                    errors.append(u"{0}: {1}".format(record["sequence"], error))
        return errors

    errors = _transaction(doc, "Assign ACP panel IDs", update)
    message = (
        u"Stored ACP panel names and A0001 style serials on {0} panels.\n\n"
        u"Existing valid IDs were kept; blank or duplicate IDs received the next available value."
    ).format(len(records))
    if errors:
        message += u"\n\nSome values could not be written:\n" + u"\n".join(errors[:12])
    forms.alert(message, title="ACP Panel Tools")


def run_build_parameters(doc):
    records = collect_panel_records(doc)
    if not records:
        forms.alert("No Curtain Wall Panels were found in this project.", title="ACP Panel Tools")
        return
    edge_count = max([len(record["curves"]) for record in records] or [0])
    specs = _panel_specs(edge_count)
    definitions = _get_or_create_definitions(doc.Application, specs)

    def update():
        _bind_instance_parameters(doc, definitions)
        return _populate_panel_parameters(doc, records, edge_count, specs)

    errors = _transaction(doc, "Add and fill ACP panel parameters", update)
    message = (
        u"Added or updated {0} ACP parameters on {1} Curtain Wall Panels.\n"
        u"Edge length and corner angle fields were created through edge {2}.\n\n"
        u"Lengths are stored as numeric millimetres and angles as numeric degrees."
    ).format(len(specs), len(records), edge_count)
    if errors:
        message += u"\n\nValues that need review:\n" + u"\n".join(errors[:12])
    forms.alert(message, title="ACP Panel Tools")


def _material_parameter(element):
    for bip_name in ("MATERIAL_ID_PARAM",):
        try:
            bip = getattr(DB.BuiltInParameter, bip_name)
            parameter = element.get_Parameter(bip)
            if parameter is not None and parameter.StorageType == DB.StorageType.ElementId:
                return parameter
        except Exception:
            pass
    try:
        for parameter in element.Parameters:
            if parameter.StorageType != DB.StorageType.ElementId:
                continue
            name = unicode(parameter.Definition.Name).lower()
            if u"material" in name or u"مادة" in name:
                return parameter
    except Exception:
        pass
    return None


def _find_material(doc, material_id):
    if material_id is None:
        return None
    return doc.GetElement(DB.ElementId(int(material_id)))


def _duplicate_panel_type(doc, panel, material, thickness_mm, cache):
    source_type = doc.GetElement(panel.GetTypeId())
    source_type_id = element_id_number(source_type.Id)
    material_id = element_id_number(material.Id) if material is not None else 0
    cache_key = (source_type_id, material_id, round(float(thickness_mm), 5) if thickness_mm is not None else None)
    if cache_key in cache:
        return cache[cache_key]

    instance_material = _material_parameter(panel)
    type_material = _material_parameter(source_type)
    update_type_material = material is not None and (instance_material is None or instance_material.IsReadOnly)
    need_duplicate = thickness_mm is not None or update_type_material
    new_type = source_type
    if need_duplicate:
        base = u"ACP_{0}_M{1}_T{2}".format(
            source_type_id,
            material_id if update_type_material else u"KEEP",
            u"KEEP" if thickness_mm is None else u"{0:.2f}".format(float(thickness_mm)),
        )
        base = re.sub(u"[^A-Za-z0-9_-]", u"_", base)
        # Always create a fresh type copy. Reusing a named copy could change
        # other panels that a user did not check in the manager.
        new_type = source_type.Duplicate(base + u"_" + uuid.uuid4().hex[:6])
        if thickness_mm is not None:
            thickness_parameter = new_type.get_Parameter(DB.BuiltInParameter.CURTAIN_WALL_SYSPANEL_THICKNESS)
            if thickness_parameter is None or thickness_parameter.IsReadOnly:
                raise Exception("The selected Curtain Wall Panel type has no editable Thickness parameter.")
            thickness_parameter.Set(from_mm(thickness_mm))
        if update_type_material:
            new_type_material = _material_parameter(new_type)
            if new_type_material is None or new_type_material.IsReadOnly:
                raise Exception("The selected panel type has no editable material parameter.")
            new_type_material.Set(material.Id)

    panel.ChangeTypeId(new_type.Id)
    if material is not None:
        updated_panel = doc.GetElement(panel.Id)
        instance_material = _material_parameter(updated_panel)
        if instance_material is not None and not instance_material.IsReadOnly:
            instance_material.Set(material.Id)
        elif not update_type_material:
            # A type-level material may have been inherited from a duplicated type.
            current_type = doc.GetElement(updated_panel.GetTypeId())
            current_type_material = _material_parameter(current_type)
            if current_type_material is None or current_type_material.AsElementId() != material.Id:
                raise Exception("Could not assign the requested material to the selected panel.")
    cache[cache_key] = new_type
    return new_type


def apply_material_and_thickness(doc, panels, material, thickness_mm):
    if not panels:
        raise Exception("Choose at least one panel first.")
    if material is None and thickness_mm is None:
        return 0
    if thickness_mm is not None and float(thickness_mm) <= 0:
        raise Exception("Thickness must be greater than zero.")

    def update():
        cache = {}
        for panel in panels:
            _duplicate_panel_type(doc, panel, material, thickness_mm, cache)
        return len(panels)

    return _transaction(doc, "Update selected ACP panels", update)


def _net_element_ids(panels):
    from System.Collections.Generic import List
    ids = List[DB.ElementId]()
    for panel in panels:
        ids.Add(panel.Id)
    return ids


def _current_view_panel_ids(doc):
    view = doc.ActiveView
    try:
        elements = list(
            DB.FilteredElementCollector(doc, view.Id)
            .OfCategory(DB.BuiltInCategory.OST_CurtainWallPanels)
            .WhereElementIsNotElementType()
        )
        return set([element_id_number(element.Id) for element in elements])
    except Exception:
        return set()


def open_panel_manager(doc, uidoc):
    records = collect_panel_records(doc)
    if not records:
        forms.alert("No Curtain Wall Panels were found in this project.", title="ACP Panel Tools")
        return

    xaml = u'''<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
      xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
      Title="ACP Panel Manager" Height="680" Width="1160"
      WindowStartupLocation="CenterOwner" ShowInTaskbar="False" ResizeMode="CanResizeWithGrip">
      <Grid Margin="12">
        <Grid.RowDefinitions>
          <RowDefinition Height="Auto"/><RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/><RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="0,0,0,8">
          <Button x:Name="SelectAllButton" Content="Check all" Width="78" Margin="0,0,6,0"/>
          <Button x:Name="ClearButton" Content="Uncheck all" Width="88" Margin="0,0,6,0"/>
          <Button x:Name="CheckSelectedButton" Content="Check selected" Width="105" Margin="0,0,6,0"
            ToolTip="Select rows with Ctrl+click or Shift+click, then click here to check them."/>
          <Button x:Name="UncheckSelectedButton" Content="Uncheck selected" Width="120" Margin="0,0,12,0"
            ToolTip="Select rows with Ctrl+click or Shift+click, then click here to uncheck them."/>
          <CheckBox x:Name="HideUncheckedCheck" Content="Hide unchecked ACP panels only (keep the rest of the view visible)" VerticalAlignment="Center"/>
          <TextBlock x:Name="CountText" Margin="18,3,0,0"/>
        </StackPanel>
        <DataGrid x:Name="PanelGrid" Grid.Row="1" AutoGenerateColumns="False"
          CanUserAddRows="False" CanUserDeleteRows="False" IsReadOnly="False"
          SelectionMode="Extended" SelectionUnit="FullRow" HeadersVisibility="Column"
          GridLinesVisibility="Horizontal" MinHeight="300"
          ToolTip="Select rows with Ctrl+click or Shift+click. Clicking a Use checkbox on a selected row checks or unchecks all selected rows.">
          <DataGrid.Columns>
            <DataGridCheckBoxColumn Header="Use" Binding="{Binding Include, UpdateSourceTrigger=PropertyChanged}" Width="48"/>
            <DataGridTextColumn Header="Panel name" Binding="{Binding Name}" IsReadOnly="True" Width="100"/>
            <DataGridTextColumn Header="Serial" Binding="{Binding Serial}" IsReadOnly="True" Width="80"/>
            <DataGridTextColumn Header="Element ID" Binding="{Binding ElementId}" IsReadOnly="True" Width="90"/>
            <DataGridTextColumn Header="Panel type" Binding="{Binding PanelType}" IsReadOnly="True" Width="150"/>
            <DataGridTextColumn Header="Material" Binding="{Binding Material}" IsReadOnly="True" Width="*"/>
            <DataGridTextColumn Header="Width mm" Binding="{Binding Width}" IsReadOnly="True" Width="90"/>
            <DataGridTextColumn Header="Height mm" Binding="{Binding Height}" IsReadOnly="True" Width="90"/>
            <DataGridTextColumn Header="Thickness mm" Binding="{Binding Thickness}" IsReadOnly="True" Width="105"/>
            <DataGridCheckBoxColumn Header="In view" Binding="{Binding InView}" IsReadOnly="True" Width="64"/>
          </DataGrid.Columns>
        </DataGrid>
        <StackPanel Grid.Row="2" Orientation="Horizontal" Margin="0,10,0,6">
          <TextBlock Text="Set material:" VerticalAlignment="Center" Margin="0,0,6,0"/>
          <ComboBox x:Name="MaterialPicker" Width="250" DisplayMemberPath="Name" Margin="0,0,12,0"/>
          <TextBlock Text="Set thickness (mm):" VerticalAlignment="Center" Margin="0,0,6,0"/>
          <TextBox x:Name="ThicknessBox" Width="110" ToolTip="Leave blank to keep the current thickness" Margin="0,0,12,0"/>
          <Button x:Name="ApplyButton" Content="Apply to checked and isolate" Width="190" Margin="0,0,8,0"/>
          <Button x:Name="IsolateButton" Content="Isolate checked" Width="130"/>
        </StackPanel>
        <DockPanel Grid.Row="3" LastChildFill="True">
          <TextBlock x:Name="StatusText" VerticalAlignment="Center" TextWrapping="Wrap"/>
          <Button x:Name="CloseButton" Content="Close" Width="90" DockPanel.Dock="Right" Margin="10,0,0,0"/>
        </DockPanel>
      </Grid>
    </Window>'''

    class ManagerWindow(forms.WPFWindow):
        def __init__(self):
            forms.WPFWindow.__init__(self, xaml, literal_string=True)
            import clr
            for assembly_name in ("System.Data", "System.Data.Common"):
                try:
                    clr.AddReference(assembly_name)
                except Exception:
                    pass
            from System.Data import DataTable
            from System import Boolean, String
            self.table = DataTable()
            for name, column_type in (
                ("Include", Boolean), ("Name", String), ("Serial", String),
                ("ElementId", String), ("PanelType", String), ("Material", String),
                ("Width", String), ("Height", String), ("Thickness", String), ("InView", Boolean),
            ):
                self.table.Columns.Add(name, column_type)
            visible_ids = _current_view_panel_ids(doc)
            self.record_by_id = {}
            for record in records:
                row = self.table.NewRow()
                row["Include"] = False
                row["Name"] = record["name"]
                row["Serial"] = record["serial"]
                row["ElementId"] = str(record["element_id"])
                row["PanelType"] = record["panel_type"]
                row["Material"] = _material_names(record) or u"(not reported)"
                row["Width"] = u"" if record["width_mm"] is None else u"{0:.2f}".format(record["width_mm"])
                row["Height"] = u"" if record["height_mm"] is None else u"{0:.2f}".format(record["height_mm"])
                row["Thickness"] = u"" if record["thickness_mm"] is None else u"{0:.2f}".format(record["thickness_mm"])
                row["InView"] = record["element_id"] in visible_ids
                self.table.Rows.Add(row)
                self.record_by_id[record["element_id"]] = record
            self.FindName("PanelGrid").ItemsSource = self.table.DefaultView
            self.FindName("CountText").Text = u"{0} panels in project".format(len(records))
            self.material_picker = self.FindName("MaterialPicker")
            for item in sorted(list(DB.FilteredElementCollector(doc).OfClass(DB.Material)), key=lambda value: element_name(value).lower()):
                self.material_picker.Items.Add(item)
            self.FindName("SelectAllButton").Click += self.select_all
            self.FindName("ClearButton").Click += self.clear_all
            self.FindName("CheckSelectedButton").Click += self.check_selected
            self.FindName("UncheckSelectedButton").Click += self.uncheck_selected
            self.FindName("PanelGrid").PreviewMouseLeftButtonDown += self.on_grid_preview_mouse_down
            self.FindName("ApplyButton").Click += self.apply_and_isolate
            self.FindName("IsolateButton").Click += self.isolate_checked
            self.FindName("CloseButton").Click += self.close_window

        def select_all(self, sender, args):
            for row in self.table.Rows:
                row["Include"] = True

        def clear_all(self, sender, args):
            for row in self.table.Rows:
                row["Include"] = False

        def _set_selected_include(self, value):
            grid = self.FindName("PanelGrid")
            selected_rows = list(grid.SelectedItems)
            if not selected_rows:
                forms.alert(
                    u"Select one or more rows first. Use Ctrl+click for separate rows or Shift+click for a range.",
                    title="ACP Panel Manager",
                )
                return
            for row in selected_rows:
                row["Include"] = value

        def check_selected(self, sender, args):
            self._set_selected_include(True)

        def uncheck_selected(self, sender, args):
            self._set_selected_include(False)

        def on_grid_preview_mouse_down(self, sender, args):
            try:
                from System.Windows.Controls import DataGridCell
                from System.Windows.Media import VisualTreeHelper
                clicked = args.OriginalSource
                cell = None
                while clicked is not None:
                    if isinstance(clicked, DataGridCell):
                        cell = clicked
                        break
                    clicked = VisualTreeHelper.GetParent(clicked)
                if cell is None or unicode(cell.Column.Header) != u"Use":
                    return
                selected_rows = list(sender.SelectedItems)
                if len(selected_rows) < 2:
                    return
                clicked_item = cell.DataContext
                clicked_id = unicode(clicked_item["ElementId"])
                selected_ids = set([unicode(row["ElementId"]) for row in selected_rows])
                if clicked_id not in selected_ids:
                    return
                new_value = not bool(clicked_item["Include"])
                for row in selected_rows:
                    row["Include"] = new_value
                args.Handled = True
            except Exception:
                pass

        def checked_records(self):
            try:
                from System.Windows.Controls import DataGridEditingUnit
                self.FindName("PanelGrid").CommitEdit(DataGridEditingUnit.Cell, True)
                self.FindName("PanelGrid").CommitEdit(DataGridEditingUnit.Row, True)
            except Exception:
                pass
            selected = []
            for row in self.table.Rows:
                if bool(row["Include"]):
                    selected.append(self.record_by_id[int(row["ElementId"])])
            return selected

        def _set_view_state(self, selected_records):
            view = doc.ActiveView
            selected_ids = set([record["element_id"] for record in selected_records])

            def update_view():
                if view.IsTemporaryHideIsolateActive():
                    view.DisableTemporaryViewMode(DB.TemporaryViewMode.TemporaryHideIsolate)
                visible_ids = _current_view_panel_ids(doc)
                panels_in_view = [
                    record["panel"] for record in records
                    if record["element_id"] in visible_ids
                ]
                selected_in_view = [
                    record["panel"] for record in selected_records
                    if record["element_id"] in visible_ids
                ]
                if not selected_in_view:
                    raise Exception("None of the checked panels is visible in the active view after resetting temporary hide/isolate.")
                uidoc.Selection.SetElementIds(_net_element_ids(selected_in_view))
                if bool(self.FindName("HideUncheckedCheck").IsChecked):
                    unchecked = [panel for panel in panels_in_view if element_id_number(panel.Id) not in selected_ids]
                    if unchecked:
                        view.HideElementsTemporary(_net_element_ids(unchecked))
                        return u"Unchecked ACP panels are temporarily hidden; all other view elements remain visible."
                    return u"All ACP panels in this view are checked; no panels were hidden and the rest of the view remains visible."
                view.IsolateElementsTemporary(_net_element_ids(selected_in_view))
                return u"Checked panels are temporarily isolated in the active view."

            return _transaction(doc, "Temporarily isolate ACP panels", update_view)

        def _refresh_panel_rows(self):
            fresh_records = collect_panel_records(doc)
            fresh_by_id = dict([(record["element_id"], record) for record in fresh_records])
            for row in self.table.Rows:
                element_id = int(row["ElementId"])
                record = fresh_by_id.get(element_id)
                if record is None:
                    continue
                row["PanelType"] = record["panel_type"]
                row["Material"] = _material_names(record) or u"(not reported)"
                row["Width"] = u"" if record["width_mm"] is None else u"{0:.2f}".format(record["width_mm"])
                row["Height"] = u"" if record["height_mm"] is None else u"{0:.2f}".format(record["height_mm"])
                row["Thickness"] = u"" if record["thickness_mm"] is None else u"{0:.2f}".format(record["thickness_mm"])
                self.record_by_id[element_id] = record

        def isolate_checked(self, sender, args):
            try:
                selected = self.checked_records()
                if not selected:
                    raise Exception("Check at least one panel.")
                status = self._set_view_state(selected)
                self.FindName("StatusText").Text = status
            except Exception as error:
                forms.alert(unicode(error), title="ACP Panel Manager")

        def apply_and_isolate(self, sender, args):
            selected = self.checked_records()
            if not selected:
                forms.alert("Check at least one panel.", title="ACP Panel Manager")
                return
            material = self.material_picker.SelectedItem
            thickness_text = self.FindName("ThicknessBox").Text.strip()
            try:
                thickness_mm = None
                if thickness_text:
                    thickness_mm = float(thickness_text.replace(u",", u"."))
                updated = apply_material_and_thickness(
                    doc, [record["panel"] for record in selected], material, thickness_mm
                )
            except Exception as error:
                forms.alert(
                    u"The material/thickness update failed and Revit rolled back that change:\n\n{0}".format(error),
                    title="ACP Panel Manager",
                )
                return

            if updated:
                try:
                    self._refresh_panel_rows()
                except Exception:
                    pass
            try:
                status = self._set_view_state(selected)
            except Exception as error:
                if updated:
                    forms.alert(
                        u"Material/thickness was updated for {0} checked panels and committed. "
                        u"The panel table was refreshed, but view isolation failed:\n\n{1}".format(updated, error),
                        title="ACP Panel Manager",
                    )
                else:
                    forms.alert(
                        u"The panel update completed, but view isolation failed:\n\n{0}".format(error),
                        title="ACP Panel Manager",
                    )
                return
            change_text = u"No material or thickness change requested."
            if updated:
                change_text = u"Updated {0} checked panel instances. Type copies were used where needed.".format(updated)
            self.FindName("StatusText").Text = change_text + u" " + status

        def close_window(self, sender, args):
            self.Close()

    ManagerWindow().show_dialog()


def _parameter_value(parameter, doc):
    try:
        storage = parameter.StorageType
        if storage == DB.StorageType.String:
            return parameter.AsString() or u""
        if storage == DB.StorageType.Integer:
            return str(parameter.AsInteger())
        if storage == DB.StorageType.Double:
            display = parameter.AsValueString()
            return display if display else repr(parameter.AsDouble())
        if storage == DB.StorageType.ElementId:
            element_id = parameter.AsElementId()
            target = doc.GetElement(element_id)
            if target is not None:
                return u"{0} ({1})".format(element_id_number(element_id), element_name(target))
            return str(element_id_number(element_id))
    except Exception:
        pass
    try:
        return parameter.AsValueString() or u""
    except Exception:
        return u""


def _parameter_snapshot(element, doc, scope):
    values = {}
    occurrence = defaultdict(int)
    try:
        for parameter in element.Parameters:
            try:
                base_name = unicode(parameter.Definition.Name)
                occurrence[base_name] += 1
                suffix = u"" if occurrence[base_name] == 1 else u" #{0}".format(occurrence[base_name])
                key = u"{0}: {1}{2}".format(scope, base_name, suffix)
                values[key] = _parameter_value(parameter, doc)
            except Exception:
                pass
    except Exception:
        pass
    return values


def _point_mm(point):
    if point is None:
        return (None, None, None)
    return (to_mm(point.X), to_mm(point.Y), to_mm(point.Z))


def _basic_rows(records):
    headers = [
        "Sequence", "Serial_Number", "Panel_Name", "ElementId", "UniqueId",
        "PanelType", "HostElementId", "HostType", "Width_mm", "Height_mm",
        "SystemPanelThickness_mm", "SystemPanelOffset_mm", "MainFaceArea_m2",
        "Material_List", "EdgeCount", "CenterX_mm", "CenterY_mm", "CenterZ_mm",
        "FaceNormalX", "FaceNormalY", "FaceNormalZ", "GeometryStatus",
    ]
    rows = []
    for record in records:
        center = _point_mm(record["center"])
        normal = _normal_values(record)
        rows.append([
            record["sequence"], record["serial"], record["name"], record["element_id"],
            record["unique_id"], record["panel_type"], record["host_id"], record["host_type"],
            record["width_mm"], record["height_mm"], record["thickness_mm"], record["offset_mm"],
            record["face_area_sqm"], _material_names(record), len(record["curves"]),
            center[0], center[1], center[2], normal[0], normal[1], normal[2], record["status"],
        ])
    return headers, rows


def _material_sheets_rows(records):
    totals = {}
    for record in records:
        for item in record["materials"]:
            key = (item["id"], item["name"], item["source"])
            if key not in totals:
                totals[key] = {
                    "panels": set(), "area": 0.0, "area_has_value": False,
                    "volume": 0.0, "volume_has_value": False,
                }
            row = totals[key]
            row["panels"].add(record["element_id"])
            if item["area_sqm"] is not None:
                row["area"] += float(item["area_sqm"])
                row["area_has_value"] = True
            if item["volume_m3"] is not None:
                row["volume"] += float(item["volume_m3"])
                row["volume_has_value"] = True
    headers = ["Material", "MaterialElementId", "Source", "PanelCount", "TotalMaterialArea_m2", "TotalMaterialVolume_m3"]
    rows = []
    for key in sorted(totals.keys(), key=lambda item: (item[1].lower(), item[2], item[0])):
        value = totals[key]
        rows.append([
            key[1] or u"(unnamed material)", key[0], key[2], len(value["panels"]),
            value["area"] if value["area_has_value"] else None,
            value["volume"] if value["volume_has_value"] else None,
        ])
    if not rows:
        rows.append([u"(no material reported by Revit)", None, None, 0, None, None])
    return headers, rows


def _detailed_rows(records):
    headers = [
        "Sequence", "Serial_Number", "Panel_Name", "ElementId", "UniqueId",
        "PanelType", "HostElementId", "HostType", "Width_mm", "Height_mm",
        "SystemPanelThickness_mm", "SystemPanelOffset_mm", "MainFaceArea_m2",
        "Material_List", "EdgeCount", "EdgeNumber", "EdgeCurveType", "EdgeLength_mm",
        "EdgeStartX_mm", "EdgeStartY_mm", "EdgeStartZ_mm", "EdgeEndX_mm", "EdgeEndY_mm",
        "EdgeEndZ_mm", "CornerAngleAtEdgeEnd_deg", "FaceNormalX", "FaceNormalY",
        "FaceNormalZ", "GeometryStatus",
    ]
    rows = []
    for record in records:
        normal = _normal_values(record)
        common = [
            record["sequence"], record["serial"], record["name"], record["element_id"],
            record["unique_id"], record["panel_type"], record["host_id"], record["host_type"],
            record["width_mm"], record["height_mm"], record["thickness_mm"], record["offset_mm"],
            record["face_area_sqm"], _material_names(record), len(record["curves"]),
        ]
        if not record["curves"]:
            rows.append(common + [None] * 10 + list(normal) + [record["status"]])
            continue
        for index, curve in enumerate(record["curves"]):
            start = _point_mm(curve.GetEndPoint(0))
            end = _point_mm(curve.GetEndPoint(1))
            rows.append(common + [
                index + 1, curve.GetType().Name, to_mm(curve.Length),
                start[0], start[1], start[2], end[0], end[1], end[2],
                record["angles"][index] if index < len(record["angles"]) else None,
            ] + list(normal) + [record["status"]])
    return headers, rows


def _fabrication_rows(records):
    headers = [
        "Sequence", "Serial_Number", "Panel_Name", "ElementId", "PanelType",
        "Width_mm", "Height_mm", "SystemPanelThickness_mm", "EdgeCount",
        "EdgeNumber", "EdgeLength_mm", "CornerAngleAtEdgeEnd_deg", "EdgeCurveType",
        "MeasurementBasis", "GeometryStatus",
    ]
    rows = []
    basis = u"Raw Revit face geometry; no clearance, kerf, fold or bend deduction applied."
    for record in records:
        common = [
            record["sequence"], record["serial"], record["name"], record["element_id"],
            record["panel_type"], record["width_mm"], record["height_mm"],
            record["thickness_mm"], len(record["curves"]),
        ]
        if not record["curves"]:
            rows.append(common + [None, None, None, None, basis, record["status"]])
            continue
        for index, curve in enumerate(record["curves"]):
            rows.append(common + [
                index + 1, to_mm(curve.Length),
                record["angles"][index] if index < len(record["angles"]) else None,
                curve.GetType().Name, basis, record["status"],
            ])
    return headers, rows


def _all_parameter_rows(doc, records):
    snapshots = []
    parameter_headers = set()
    for record in records:
        values = {}
        values.update(_parameter_snapshot(record["panel"], doc, u"Instance"))
        values.update(_parameter_snapshot(record["panel_type_element"], doc, u"Type"))
        snapshots.append(values)
        for key in values.keys():
            parameter_headers.add(key)
    fixed = ["Sequence", "Serial_Number", "Panel_Name", "ElementId", "UniqueId", "PanelTypeId"]
    headers = fixed + sorted(parameter_headers, key=lambda value: value.lower())
    rows = []
    for record, values in zip(records, snapshots):
        row = [
            record["sequence"], record["serial"], record["name"], record["element_id"],
            record["unique_id"], element_id_number(record["panel_type_element"].Id),
        ]
        row.extend([values.get(header, u"") for header in headers[len(fixed):]])
        rows.append(row)
    return headers, rows


def _xml_text(value):
    if value is None:
        return u""
    try:
        text = unicode(value)
    except Exception:
        text = str(value)
    text = re.sub(u"[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]", u"", text)
    return (text.replace(u"&", u"&amp;").replace(u"<", u"&lt;")
            .replace(u">", u"&gt;").replace(u'"', u"&quot;").replace(u"'", u"&apos;"))


def _column_name(index):
    result = u""
    while index:
        index, remainder = divmod(index - 1, 26)
        result = unichr(65 + remainder) + result
    return result


def _xlsx_sheet_xml(headers, rows):
    all_rows = [headers] + rows
    xml_rows = []
    for row_index, values in enumerate(all_rows, 1):
        cells = []
        for column_index, value in enumerate(values, 1):
            address = u"{0}{1}".format(_column_name(column_index), row_index)
            if row_index == 1:
                style = u' s="1"'
            else:
                style = u""
            if value is None:
                cells.append(u'<c r="{0}"{1}/>'.format(address, style))
            elif isinstance(value, bool):
                cells.append(u'<c r="{0}"{1} t="b"><v>{2}</v></c>'.format(address, style, u"1" if value else u"0"))
            elif isinstance(value, (int, long, float)):
                if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                    cells.append(u'<c r="{0}"{1}/>'.format(address, style))
                else:
                    cells.append(u'<c r="{0}"{1}><v>{2}</v></c>'.format(address, style, repr(value)))
            else:
                text = _xml_text(value)
                cells.append(u'<c r="{0}"{1} t="inlineStr"><is><t xml:space="preserve">{2}</t></is></c>'.format(address, style, text))
        xml_rows.append(u'<row r="{0}">{1}</row>'.format(row_index, u"".join(cells)))
    last_col = _column_name(len(headers))
    last_row = max(1, len(all_rows))
    columns = u'<cols><col min="1" max="{0}" width="24" customWidth="1"/></cols>'.format(len(headers))
    return (
        u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        u'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        u'<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
        u'<sheetFormatPr defaultRowHeight="15"/>{3}<sheetData>{0}</sheetData>'
        u'<autoFilter ref="A1:{1}{2}"/></worksheet>'
    ).format(u"".join(xml_rows), last_col, last_row, columns)


def _xlsx_styles_xml():
    return (
        u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        u'<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        u'<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>'
        u'<font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts>'
        u'<fills count="3"><fill><patternFill patternType="none"/></fill>'
        u'<fill><patternFill patternType="gray125"/></fill>'
        u'<fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill></fills>'
        u'<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
        u'<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        u'<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        u'<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs>'
        u'<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
    )


def write_xlsx(output_path, sheets):
    content_types = [
        u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        u'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
        u'<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
        u'<Default Extension="xml" ContentType="application/xml"/>',
        u'<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
        u'<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
    ]
    workbook_sheets = []
    workbook_rels = []
    for index, sheet in enumerate(sheets, 1):
        content_types.append(u'<Override PartName="/xl/worksheets/sheet{0}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'.format(index))
        workbook_sheets.append(u'<sheet name="{0}" sheetId="{1}" r:id="rId{1}"/>'.format(_xml_text(sheet[0]), index))
        workbook_rels.append(u'<Relationship Id="rId{0}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{0}.xml"/>'.format(index))
    style_rel_id = len(sheets) + 1
    workbook_rels.append(u'<Relationship Id="rId{0}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'.format(style_rel_id))
    content_types.append(u'</Types>')
    workbook_xml = (
        u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        u'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        u'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        u'<bookViews><workbookView/></bookViews><sheets>{0}</sheets></workbook>'
    ).format(u"".join(workbook_sheets))
    rels_root = u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    root_rels = rels_root + u'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    workbook_rels_xml = rels_root + u"".join(workbook_rels) + u"</Relationships>"
    files = {
        u"[Content_Types].xml": u"".join(content_types),
        u"_rels/.rels": root_rels,
        u"xl/workbook.xml": workbook_xml,
        u"xl/_rels/workbook.xml.rels": workbook_rels_xml,
        u"xl/styles.xml": _xlsx_styles_xml(),
    }
    for index, sheet in enumerate(sheets, 1):
        files[u"xl/worksheets/sheet{0}.xml".format(index)] = _xlsx_sheet_xml(sheet[1], sheet[2])
    archive = zipfile.ZipFile(output_path, "w", zipfile.ZIP_STORED)
    try:
        for name, content in files.items():
            archive.writestr(name.encode("utf-8"), content.encode("utf-8"))
    finally:
        archive.close()


def export_excel(doc):
    records = collect_panel_records(doc)
    if not records:
        forms.alert("No Curtain Wall Panels were found in this project.", title="ACP Panel Tools")
        return
    output_path = forms.save_file(
        file_ext="xlsx",
        files_filter="Excel Workbook (*.xlsx)|*.xlsx",
        default_name="ACP_Panel_Detailed_Survey.xlsx",
        title="Save ACP Panel Workbook",
    )
    if not output_path:
        return
    sheets = [
        (u"BASIC DIMENSION",) + _basic_rows(records),
        (u"MATERIALS",) + _material_sheets_rows(records),
        (u"FULL DETAILED",) + _detailed_rows(records),
        (u"FABRICATION",) + _fabrication_rows(records),
        (u"ALL PARAMETERS",) + _all_parameter_rows(doc, records),
    ]
    try:
        write_xlsx(output_path, sheets)
    except Exception as error:
        forms.alert(u"Could not create the workbook:\n{0}".format(error), title="ACP Panel Tools")
        return
    forms.alert(
        u"Workbook saved with five tabs for {0} panels.\n\n"
        u"Fabrication dimensions are raw Revit face measurements. No clearance or fold deduction was applied."
        .format(len(records)),
        title="ACP Panel Tools",
    )


def _version_key(value):
    parts = [int(part) for part in re.findall(r"\d+", unicode(value))]
    return tuple(parts or [0])


def _compare_versions(left, right):
    left_parts = list(_version_key(left))
    right_parts = list(_version_key(right))
    size = max(len(left_parts), len(right_parts))
    left_parts.extend([0] * (size - len(left_parts)))
    right_parts.extend([0] * (size - len(right_parts)))
    return (left_parts > right_parts) - (left_parts < right_parts)


def run_check_updates():
    config_path = os.path.join(EXTENSION_ROOT, "update_config.json")
    version_path = os.path.join(EXTENSION_ROOT, "VERSION.txt")
    if not os.path.exists(config_path):
        forms.alert(
            u"Update checking is not configured yet. Add your public GitHub repository to update_config.json.",
            title="S_ACP Updates",
        )
        return
    try:
        with open(config_path, "r") as config_file:
            config = json.load(config_file)
        repository = unicode(config.get("repository", u"")).strip().strip(u"/")
        if repository.upper() == u"OWNER/REPOSITORY":
            forms.alert(
                u"The GitHub repository has not been connected yet. Send me its link and I will configure this button.",
                title="S_ACP Updates",
            )
            return
        if not re.match(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$", repository):
            raise Exception("The GitHub repository must use the format owner/repository.")
        with open(version_path, "r") as version_file:
            current_version = version_file.read().strip()
        if not current_version:
            current_version = u"0.0.0"
    except Exception as error:
        forms.alert(u"Could not read the update settings:\n{0}".format(error), title="S_ACP Updates")
        return

    try:
        from System.Net import HttpWebRequest, SecurityProtocolType, ServicePointManager
        try:
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
        except Exception:
            pass
        url = u"https://api.github.com/repos/{0}/releases/latest".format(repository)
        request = HttpWebRequest.Create(url)
        request.Method = "GET"
        request.UserAgent = "S_ACP-Revit-Update-Checker"
        request.Accept = "application/vnd.github+json"
        request.Headers.Add("X-GitHub-Api-Version", "2022-11-28")
        request.Timeout = 15000
        response = request.GetResponse()
        try:
            from System.IO import StreamReader
            reader = StreamReader(response.GetResponseStream())
            try:
                release = json.loads(reader.ReadToEnd())
            finally:
                reader.Close()
        finally:
            response.Close()
    except Exception as error:
        forms.alert(
            u"Could not check GitHub for updates. Check your internet connection and repository settings.\n\n{0}".format(error),
            title="S_ACP Updates",
        )
        return

    latest_version = unicode(release.get("tag_name", u"")).strip()
    release_url = unicode(release.get("html_url", u"")).strip()
    if not latest_version:
        forms.alert(
            u"GitHub did not return a published release for {0}. Create a release with a version tag, such as v1.0.1.".format(repository),
            title="S_ACP Updates",
        )
        return
    comparison = _compare_versions(latest_version, current_version)
    if comparison <= 0:
        forms.alert(
            u"S_ACP is up to date.\nInstalled version: {0}\nLatest release: {1}".format(current_version, latest_version),
            title="S_ACP Updates",
        )
        return

    choice = forms.alert(
        u"A newer S_ACP release is available.\nInstalled: {0}\nLatest: {1}\n\nOpen the GitHub release page to download it?".format(
            current_version, latest_version
        ),
        title="S_ACP Updates",
        options=["Open release page", "Later"],
        warn_icon=False,
    )
    if choice == "Open release page" and release_url:
        try:
            from System.Diagnostics import Process
            Process.Start(release_url)
        except Exception as error:
            forms.alert(u"Could not open the release page:\n{0}\n\n{1}".format(release_url, error), title="S_ACP Updates")


def safe_run(callback, *args):
    try:
        return callback(*args)
    except Exception as error:
        forms.alert(
            u"The ACP tool could not finish this action:\n{0}".format(error),
            title="ACP Panel Tools",
        )
